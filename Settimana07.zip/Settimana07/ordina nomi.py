nomi = [ 'GIovanni', 'antONIO', 'BEATRICe', 'franco']

nomi2 = []
for nome in nomi:
    nomi2.append(nome.upper())
print(nomi2)
print(sorted(nomi2))

for i in range(len(nomi)):
    nomi[i] = nomi[i].upper()
