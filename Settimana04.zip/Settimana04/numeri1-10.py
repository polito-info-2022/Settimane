# stampa i numeri da 1 a 10

n = 1
while n<=10 :
    print(n)
    n = n + 1
