# Programma introduttivo di esempio

import math

# Cateti
a = 3.0
b = 4.0

# Calcolo ipotenusa

c = math.sqrt(a*a + b*b)

print('Il triangolo con cateti', a, b, 'ha ipotenusa pari a', c)