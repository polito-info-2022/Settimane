# Gym time - `while` edition

* Leggere da tastiera una serie di numeri interi positivi, terminando l'inserimento con il valore -1, e stampare la loro somma.
  * Variante: terminare l'inserimento inserendo una riga vuota
  * Variante: terminare l'inserimento inserendo un asterisco *
  * Estensione: se il valore inserito non è valido (es. è negativo), ri-chiederlo
  * Estensione: alla fine del ciclo, dire se sono stati inseriti dei multipli di 3

* Leggere da tastiera una serie di 5 caratteri alfabetici, e stampare la stringa corrispondente alla loro concatenazione, tutta in maiuscolo
  * Estensione: se il carattere inserito non è alfabetico, o non è composto da un singolo carattere, ignorarlo
  * Estensione: fare in modo che il programma non accetti caratteri consecutivi identici