s = input("inserisci qualcosa: ")
print('*'+s+'*')

n = int(s)
print(n)
