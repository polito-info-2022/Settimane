print("ciao", 3+2)
print(33)
print("3+2")   # stampa in modo letterale, non fa i calcoli
print()
print('333')
# print(ciao)
