# Testing different types in the same variable
taxRate = 5  # int
print(taxRate)

taxrate = 5.5  # float
print(taxRate)

taxRate = "Non-taxable" # string
print(taxRate)
