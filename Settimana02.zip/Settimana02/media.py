# from math import sqrt
import math

a = 5
b = 10
print(a+1, b)

c = math.sqrt(b)